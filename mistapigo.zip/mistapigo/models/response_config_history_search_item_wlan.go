package models

import (
    "encoding/json"
    "errors"
    "github.com/google/uuid"
    "strings"
)

// ResponseConfigHistorySearchItemWlan represents a ResponseConfigHistorySearchItemWlan struct.
type ResponseConfigHistorySearchItemWlan struct {
    Auth                 string         `json:"auth"`
    Bands                []string       `json:"bands,omitempty"`
    Id                   uuid.UUID      `json:"id"`
    Ssid                 string         `json:"ssid"`
    VlanIds              []string       `json:"vlan_ids,omitempty"`
    AdditionalProperties map[string]any `json:"_"`
}

// MarshalJSON implements the json.Marshaler interface for ResponseConfigHistorySearchItemWlan.
// It customizes the JSON marshaling process for ResponseConfigHistorySearchItemWlan objects.
func (r ResponseConfigHistorySearchItemWlan) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(r.toMap())
}

// toMap converts the ResponseConfigHistorySearchItemWlan object to a map representation for JSON marshaling.
func (r ResponseConfigHistorySearchItemWlan) toMap() map[string]any {
    structMap := make(map[string]any)
    MapAdditionalProperties(structMap, r.AdditionalProperties)
    structMap["auth"] = r.Auth
    if r.Bands != nil {
        structMap["bands"] = r.Bands
    }
    structMap["id"] = r.Id
    structMap["ssid"] = r.Ssid
    if r.VlanIds != nil {
        structMap["vlan_ids"] = r.VlanIds
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for ResponseConfigHistorySearchItemWlan.
// It customizes the JSON unmarshaling process for ResponseConfigHistorySearchItemWlan objects.
func (r *ResponseConfigHistorySearchItemWlan) UnmarshalJSON(input []byte) error {
    var temp responseConfigHistorySearchItemWlan
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    err = temp.validate()
    if err != nil {
    	return err
    }
    additionalProperties, err := UnmarshalAdditionalProperties(input, "auth", "bands", "id", "ssid", "vlan_ids")
    if err != nil {
    	return err
    }
    
    r.AdditionalProperties = additionalProperties
    r.Auth = *temp.Auth
    r.Bands = temp.Bands
    r.Id = *temp.Id
    r.Ssid = *temp.Ssid
    r.VlanIds = temp.VlanIds
    return nil
}

// responseConfigHistorySearchItemWlan is a temporary struct used for validating the fields of ResponseConfigHistorySearchItemWlan.
type responseConfigHistorySearchItemWlan  struct {
    Auth    *string    `json:"auth"`
    Bands   []string   `json:"bands,omitempty"`
    Id      *uuid.UUID `json:"id"`
    Ssid    *string    `json:"ssid"`
    VlanIds []string   `json:"vlan_ids,omitempty"`
}

func (r *responseConfigHistorySearchItemWlan) validate() error {
    var errs []string
    if r.Auth == nil {
        errs = append(errs, "required field `auth` is missing for type `Response_Config_History_Search_Item_Wlan`")
    }
    if r.Id == nil {
        errs = append(errs, "required field `id` is missing for type `Response_Config_History_Search_Item_Wlan`")
    }
    if r.Ssid == nil {
        errs = append(errs, "required field `ssid` is missing for type `Response_Config_History_Search_Item_Wlan`")
    }
    if len(errs) == 0 {
        return nil
    }
    return errors.New(strings.Join(errs, "\n"))
}
