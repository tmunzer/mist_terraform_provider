package models

import (
    "encoding/json"
)

// GatewayStatsDhcpdLan represents a GatewayStatsDhcpdLan struct.
type GatewayStatsDhcpdLan struct {
    NumIps               *int           `json:"num_ips,omitempty"`
    NumLeased            *int           `json:"num_leased,omitempty"`
    AdditionalProperties map[string]any `json:"_"`
}

// MarshalJSON implements the json.Marshaler interface for GatewayStatsDhcpdLan.
// It customizes the JSON marshaling process for GatewayStatsDhcpdLan objects.
func (g GatewayStatsDhcpdLan) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(g.toMap())
}

// toMap converts the GatewayStatsDhcpdLan object to a map representation for JSON marshaling.
func (g GatewayStatsDhcpdLan) toMap() map[string]any {
    structMap := make(map[string]any)
    MapAdditionalProperties(structMap, g.AdditionalProperties)
    if g.NumIps != nil {
        structMap["num_ips"] = g.NumIps
    }
    if g.NumLeased != nil {
        structMap["num_leased"] = g.NumLeased
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for GatewayStatsDhcpdLan.
// It customizes the JSON unmarshaling process for GatewayStatsDhcpdLan objects.
func (g *GatewayStatsDhcpdLan) UnmarshalJSON(input []byte) error {
    var temp gatewayStatsDhcpdLan
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    additionalProperties, err := UnmarshalAdditionalProperties(input, "num_ips", "num_leased")
    if err != nil {
    	return err
    }
    
    g.AdditionalProperties = additionalProperties
    g.NumIps = temp.NumIps
    g.NumLeased = temp.NumLeased
    return nil
}

// gatewayStatsDhcpdLan is a temporary struct used for validating the fields of GatewayStatsDhcpdLan.
type gatewayStatsDhcpdLan  struct {
    NumIps    *int `json:"num_ips,omitempty"`
    NumLeased *int `json:"num_leased,omitempty"`
}
