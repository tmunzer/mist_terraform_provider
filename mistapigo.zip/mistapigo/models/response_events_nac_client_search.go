package models

import (
    "encoding/json"
)

// ResponseEventsNacClientSearch represents a ResponseEventsNacClientSearch struct.
type ResponseEventsNacClientSearch struct {
    End                  *int             `json:"end,omitempty"`
    Limit                *int             `json:"limit,omitempty"`
    Results              []EventNacClient `json:"results,omitempty"`
    Start                *int             `json:"start,omitempty"`
    Total                *int             `json:"total,omitempty"`
    AdditionalProperties map[string]any   `json:"_"`
}

// MarshalJSON implements the json.Marshaler interface for ResponseEventsNacClientSearch.
// It customizes the JSON marshaling process for ResponseEventsNacClientSearch objects.
func (r ResponseEventsNacClientSearch) MarshalJSON() (
    []byte,
    error) {
    return json.Marshal(r.toMap())
}

// toMap converts the ResponseEventsNacClientSearch object to a map representation for JSON marshaling.
func (r ResponseEventsNacClientSearch) toMap() map[string]any {
    structMap := make(map[string]any)
    MapAdditionalProperties(structMap, r.AdditionalProperties)
    if r.End != nil {
        structMap["end"] = r.End
    }
    if r.Limit != nil {
        structMap["limit"] = r.Limit
    }
    if r.Results != nil {
        structMap["results"] = r.Results
    }
    if r.Start != nil {
        structMap["start"] = r.Start
    }
    if r.Total != nil {
        structMap["total"] = r.Total
    }
    return structMap
}

// UnmarshalJSON implements the json.Unmarshaler interface for ResponseEventsNacClientSearch.
// It customizes the JSON unmarshaling process for ResponseEventsNacClientSearch objects.
func (r *ResponseEventsNacClientSearch) UnmarshalJSON(input []byte) error {
    var temp responseEventsNacClientSearch
    err := json.Unmarshal(input, &temp)
    if err != nil {
    	return err
    }
    additionalProperties, err := UnmarshalAdditionalProperties(input, "end", "limit", "results", "start", "total")
    if err != nil {
    	return err
    }
    
    r.AdditionalProperties = additionalProperties
    r.End = temp.End
    r.Limit = temp.Limit
    r.Results = temp.Results
    r.Start = temp.Start
    r.Total = temp.Total
    return nil
}

// responseEventsNacClientSearch is a temporary struct used for validating the fields of ResponseEventsNacClientSearch.
type responseEventsNacClientSearch  struct {
    End     *int             `json:"end,omitempty"`
    Limit   *int             `json:"limit,omitempty"`
    Results []EventNacClient `json:"results,omitempty"`
    Start   *int             `json:"start,omitempty"`
    Total   *int             `json:"total,omitempty"`
}
